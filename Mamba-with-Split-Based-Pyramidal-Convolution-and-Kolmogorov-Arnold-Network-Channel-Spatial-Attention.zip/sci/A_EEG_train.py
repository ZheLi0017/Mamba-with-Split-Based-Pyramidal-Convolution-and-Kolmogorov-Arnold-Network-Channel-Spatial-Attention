import os
from barbar import Bar
# from ignite.metrics import Accuracy
import itertools
from torch.autograd import Variable
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from torch.optim import lr_scheduler
import numpy as np
import torch
import torch.nn as nn
from torch.nn import functional as F
from einops import rearrange
import math
import torchmetrics
from torch.nn.functional import conv1d

from mambapy.mamba import MambaConfig, ResidualBlock

class SpatialAtt1D(nn.Module):
    """
    inputs = torch.rand([8,64,80])
    m = SpatialAtt1D()
    out = m(inputs)
    r = inputs * out
    print(r.shape)
    """
    def __init__(self, kernel_size=7):
        super(SpatialAtt1D, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv1d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x_):
        x = x_.clone()
        avg_out = torch.mean(x, dim=1, keepdim=True)
        # print(avg_out.shape)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        # print(max_out.shape)
        x = torch.cat([avg_out, max_out], dim=1)
        # print(x.shape)
        x = self.conv1(x)
        # print(x.shape)
        return x_ * self.sigmoid(x)

class KANLayer(nn.Module):
    def __init__(self, input_features, output_features, grid_size=5, spline_order=3, base_activation=nn.GELU,
                 grid_range=[-1, 1]):
        super(KANLayer, self).__init__()
        self.input_features = input_features
        self.output_features = output_features

        # The number of points in the grid for the spline interpolation.
        self.grid_size = grid_size
        # The order of the spline used in the interpolation.
        self.spline_order = spline_order
        # Activation function used for the initial transformation of the input.
        self.base_activation = base_activation()
        # The range of values over which the grid for spline interpolation is defined.
        self.grid_range = grid_range

        # Initialize the base weights with random values for the linear transformation.
        self.base_weight = nn.Parameter(torch.randn(output_features, input_features))
        # Initialize the spline weights with random values for the spline transformation.
        self.spline_weight = nn.Parameter(torch.randn(output_features, input_features, grid_size + spline_order))
        # Add a layer normalization for stabilizing the output of this layer.
        self.layer_norm = nn.LayerNorm(output_features)
        # Add a PReLU activation for this layer to provide a learnable non-linearity.
        self.prelu = nn.PReLU()

        # Compute the grid values based on the specified range and grid size.
        h = (self.grid_range[1] - self.grid_range[0]) / grid_size
        self.grid = torch.linspace(
            self.grid_range[0] - h * spline_order,
            self.grid_range[1] + h * spline_order,
            grid_size + 2 * spline_order + 1,
            dtype=torch.float32
        ).expand(input_features, -1).contiguous()

        # Initialize the weights using Kaiming uniform distribution for better initial values.
        nn.init.kaiming_uniform_(self.base_weight, nonlinearity='linear')
        nn.init.kaiming_uniform_(self.spline_weight, nonlinearity='linear')

    def forward(self, x):
        # Process each layer using the defined base weights, spline weights, norms, and activations.
        grid = self.grid.to(x.device)
        # Move the input tensor to the device where the weights are located.

        # Perform the base linear transformation followed by the activation function.
        base_output = F.linear(self.base_activation(x), self.base_weight)
        x_uns = x.unsqueeze(-1)  # Expand dimensions for spline operations.
        # Compute the basis for the spline using intervals and input values.
        bases = ((x_uns >= grid[:, :-1]) & (x_uns < grid[:, 1:])).to(x.dtype).to(x.device)

        # Compute the spline basis over multiple orders.
        for k in range(1, self.spline_order + 1):
            left_intervals = grid[:, :-(k + 1)]
            right_intervals = grid[:, k:-1]
            delta = torch.where(right_intervals == left_intervals, torch.ones_like(right_intervals),
                                right_intervals - left_intervals)
            bases = ((x_uns - left_intervals) / delta * bases[:, :, :-1]) + \
                    ((grid[:, k + 1:] - x_uns) / (grid[:, k + 1:] - grid[:, 1:(-k)]) * bases[:, :, 1:])
        bases = bases.contiguous()

        # Compute the spline transformation and combine it with the base transformation.
        spline_output = F.linear(bases.view(x.size(0), -1), self.spline_weight.view(self.spline_weight.size(0), -1))
        # Apply layer normalization and PReLU activation to the combined output.
        x = self.prelu(self.layer_norm(base_output + spline_output))

        return x

class KANattention(nn.Module):
    def __init__(self, in_planes, ratio=8):
        super(KANattention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)

        self.fc1 = KANLayer(in_planes, in_planes // ratio, grid_size=5, spline_order=3, base_activation=nn.GELU,
                            grid_range=[-1, 1])
        self.fc2 = KANLayer(in_planes // ratio, in_planes, grid_size=5, spline_order=3, base_activation=nn.GELU,
                            grid_range=[-1, 1])

    def forward(self, x):
        x = x.transpose(-1, -2)
        avg_out = self.fc2(self.fc1(self.avg_pool(x).squeeze(-1)))
        max_out = self.fc2(self.fc1(self.max_pool(x).squeeze(-1)))
        out = (avg_out + max_out).unsqueeze(-1)
        # print(out.shape)
        return (out * x).transpose(-1, -2)


class SPConv_1d(nn.Module):
    # padding = int((kernel_size-1-(kernel_size-1)*(dilation-1))/2)
    def __init__(self, inplanes, outplanes, kernel_size, groups=1, dilation=1, bias=False, ratio=0.5):
        super(SPConv_1d, self).__init__()
        self.inplanes_3x3 = int(inplanes * ratio)
        self.inplanes_1x1 = inplanes - self.inplanes_3x3
        self.outplanes_3x3 = int(outplanes * ratio)
        self.outplanes_1x1 = outplanes - self.outplanes_3x3
        self.outplanes = outplanes
        self.stride = 1

        self.gwc = nn.Conv1d(self.inplanes_3x3, self.outplanes, kernel_size=kernel_size, stride=self.stride,
                             padding=int((kernel_size - 1 - (kernel_size - 1) * (dilation - 1)) / 2), groups=groups,
                             bias=bias)
        self.pwc = nn.Conv1d(self.inplanes_3x3, self.outplanes, kernel_size=1, bias=False)

        self.conv1x1 = nn.Conv1d(self.inplanes_1x1, self.outplanes, kernel_size=1)
        self.avgpool_s2_1 = nn.AvgPool1d(kernel_size=2, stride=2)
        self.avgpool_s2_3 = nn.AvgPool1d(kernel_size=2, stride=2)
        self.avgpool_add_1 = nn.AdaptiveAvgPool1d(1)
        self.avgpool_add_3 = nn.AdaptiveAvgPool1d(1)
        self.bn1 = nn.BatchNorm1d(self.outplanes)
        self.bn2 = nn.BatchNorm1d(self.outplanes)
        self.ratio = ratio
        self.groups = int(1 / self.ratio)

    def forward(self, x):
        b, c, _ = x.size()

        # p1
        x_3x3 = x[:, :int(c * self.ratio), :]
        x_1x1 = x[:, int(c * self.ratio):, :]
        out_3x3_gwc = self.gwc(x_3x3)
        if self.stride == 2:
            x_3x3 = self.avgpool_s2_3(x_3x3)
        out_3x3_pwc = self.pwc(x_3x3)
        out_3x3 = out_3x3_gwc + out_3x3_pwc
        out_3x3 = self.bn1(out_3x3)
        out_3x3_ratio = self.avgpool_add_3(out_3x3).squeeze()

        # p2 # use avgpool first to reduce information lost
        if self.stride == 2:
            x_1x1 = self.avgpool_s2_1(x_1x1)

        out_1x1 = self.conv1x1(x_1x1)
        out_1x1 = self.bn2(out_1x1)
        out_1x1_ratio = self.avgpool_add_1(out_1x1).squeeze()

        # p3
        out_31_ratio = torch.stack((out_3x3_ratio, out_1x1_ratio), 2)
        out_31_ratio = nn.Softmax(dim=2)(out_31_ratio)
        out = out_1x1 * (out_31_ratio[:, :, 1].view(b, self.outplanes, 1).expand_as(out_1x1)) \
              + out_3x3 * (out_31_ratio[:, :, 0].view(b, self.outplanes, 1).expand_as(out_3x3))

        return out


class PySPConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, pyconv_kernels, pyconv_groups, stride=1, dilation=1, bias=False):
        super(PySPConv1d, self).__init__()

        assert len(out_channels) == len(pyconv_kernels) == len(pyconv_groups)

        self.pyconv_levels = [None] * len(pyconv_kernels)
        for i in range(len(pyconv_kernels)):
            # self.pyconv_levels[i] = nn.Conv1d(in_channels, out_channels[i], kernel_size=pyconv_kernels[i],
            #                                   stride=stride, padding=pyconv_kernels[i] // 2, groups=pyconv_groups[i],
            #                                   dilation=dilation, bias=bias)
            self.pyconv_levels[i] = SPConv_1d(in_channels, out_channels[i], kernel_size=pyconv_kernels[i],
                                              groups=pyconv_groups[i], dilation=dilation, bias=bias)

        self.pyconv_levels = nn.ModuleList(self.pyconv_levels)

    def forward(self, x):
        out = []
        for level in self.pyconv_levels:
            out.append(level(x))

        return torch.cat(out, 1)


class Mamba(nn.Module):
    def __init__(self, config: MambaConfig):
        super().__init__()

        self.config = config

        self.layers = nn.ModuleList([ResidualBlock(config) for _ in range(config.n_layers)])

        for i, layer in enumerate(self.layers):
            ch = config.d_inner * (2 ** i)
            layer: ResidualBlock
            # layer.mixer.conv1d = mixConv1d(ch)
            layer.mixer.conv1d = PySPConv1d(in_channels=ch,
                                            out_channels=[int(ch / 4), int(ch / 4), int(ch / 4), int(ch / 4)],
                                            pyconv_kernels=[3, 5, 7, 11], pyconv_groups=[1, 4, 8, 8])

        self.attention1 = KANattention(config.d_model)
        self.attention2 = SpatialAtt1D()

        self.downsamples = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(config.d_model, config.d_model, kernel_size=3, stride=2, padding=1),
                nn.ReLU(),
                nn.BatchNorm1d(config.d_model),
            )
        ])

    def forward(self, x):
        #  x : (B, L, D)

        #  y : (B, L, D)

        for layer, downsample in zip(self.layers, self.downsamples):
            x = layer(x)
            x = x.permute(0, 2, 1)
            x = downsample(x)
            x = x.permute(0, 2, 1)

        x = self.attention2(self.attention1(x))
        return x

    def step(self, x, caches):
        #  x : (B, L, D)
        #  caches : [cache(layer) for all layers], cache : (h, inputs)

        #  y : (B, L, D)
        #  caches : [cache(layer) for all layers], cache : (h, inputs)

        for i, (layer, downsample) in enumerate(zip(self.layers, self.downsamples)):
            x, caches[i] = layer.step(x, caches[i])
            x = x.permute(0, 2, 1)
            x = downsample(x)
            x = x.permute(0, 2, 1)

        x = self.attention2(self.attention1(x))
        return x, caches


class MambaModel(nn.Module):
    def __init__(self,in_ch,n_cla,d_model):
        super().__init__()

        self.in_proj = nn.Conv1d(in_ch, d_model, kernel_size=3, padding=1)

        config = MambaConfig(
            d_model=d_model,
            n_layers=3,
            d_state=64,
        )
        self.mamba = Mamba(config)

        self.predictor = nn.Linear(d_model, n_cla)

    def forward(self, x):
        x = self.in_proj(x)
        x = x.permute(0, 2, 1)
        x = self.mamba(x)
        x = x.mean(dim=1)
        return self.predictor(x)


class ConvModel(nn.Module):
    def __init__(self):
        super().__init__()

        self.layers = nn.Sequential(
            nn.Conv1d(22, 128, kernel_size=3),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.MaxPool1d(kernel_size=4),
            nn.Conv1d(128, 256, kernel_size=3),
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.MaxPool1d(kernel_size=4),
            nn.Conv1d(256, 256, kernel_size=3),
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.MaxPool1d(kernel_size=4),
            nn.Conv1d(256, 256, kernel_size=3),
            nn.ReLU(),
            nn.BatchNorm1d(256),
        )

        self.predictor = nn.Linear(256, 4)

    def forward(self, x):
        x = self.layers(x)
        x = x.mean(dim=-1)
        return self.predictor(x)


def plot_confusion_matrix(cm, classes, normalize=True, title='Confusion matrix', cmap=plt.cm.Blues):
    """
    - cm : 计算出的混淆矩阵的值
    - classes : 混淆矩阵中每一行每一列对应的列
    - normalize : True:显示百分比, False:显示个数
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("显示百分比：")
        np.set_printoptions(formatter={'float': '{: 0.2f}'.format})
        print(cm)
    else:
        print('显示具体数字：')
        print(cm)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=90)
    plt.yticks(tick_marks, classes)

    plt.ylim(len(classes) - 0.5, -0.5)
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.show()


class trainend:

    def __init__(self, patience=7, m_new=0, verbose=True, delta=0, path='checkpoint.pt', trace_func=print):

        self.patience = patience
        self.m_new = m_new
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.traend = False
        self.val_loss_min = 0
        self.delta = delta
        self.path = path
        self.trace_func = trace_func

    def __call__(self, val_loss, model):
        score = val_loss
        if self.best_score is None:
            self.best_score = score
            # self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            self.trace_func(f'{self.counter} out of {self.patience}')
            if self.counter >= self.patience or score >= 0.997:
                self.traend = True
        elif score > 0.5:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        '''Saves model when monitored metric decrease.'''
        if self.verbose:
            self.trace_func(f'Monitored metric has improved ({self.val_loss_min} --> {val_loss}).  Saving model ...')
        torch.save(model.state_dict(), 'save/ecgnet.pt')
        self.val_loss_min = val_loss


# 组建自己的数据集
class mydataset(Dataset):
    def __init__(self, data, label):
        self.datas = data
        self.labels = label

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        data = torch.tensor(self.datas[index], dtype=torch.float32)
        # 深度学习训练集，labels必须用long类型
        label = torch.tensor(self.labels[index], dtype=torch.long)
        return data, label


EPOCHS = 100
LR = 0.0001
n_classes = 4
device = "cpu"
torch.autograd.set_detect_anomaly(True)
d_model = 128
state_size = 128  # Example state size
batch_size = 64
in_channel = 22

ecgnp = np.load('A_train.npy')
labels = np.load('A_train_lab.npy')
print(ecgnp.shape,labels.shape)

perm = np.random.permutation(ecgnp.shape[0])
ecgnp = ecgnp[perm]
labels = labels[perm]

n_label = np.unique(labels, return_counts=True)

print(n_label)

alllen = len(labels)

# model = Mamba(seq_len, d_model, state_size, n_deep = 1 ,num_cla=n_classes,device=device).to(device)
# model = MambaModel(in_ch = in_channel,n_cla=n_classes,d_model=d_model)
model = ConvModel()
model.to(device)
# print(model)

if os.path.exists('save/ecgnet.pt'):
    model.load_state_dict(torch.load('save/ecgnet.pt'))

if not os.path.exists('./anmylog/'):
    os.mkdir('./anmylog/')

for ep in range(0, 10):
    if not os.path.exists('./anmylog/' + str(ep)):
        os.mkdir('./anmylog/' + str(ep))

    # print(ecgnp[0:int(alllen*(9-ep)*0.1)].shape)

    train_dataseta = mydataset(ecgnp[0:int(alllen * (9 - ep) * 0.1)],
                               labels[0:int(alllen * (9 - ep) * 0.1)])
    train_datasetb = mydataset(ecgnp[int(alllen * (10 - ep) * 0.1):-1],
                               labels[int(alllen * (10 - ep) * 0.1):-1])
    train_dataset = train_dataseta + train_datasetb
    test_dataset = mydataset(ecgnp[int(alllen * (9 - ep) * 0.1) + 1:int(alllen * (10 - ep) * 0.1)],
                             labels[int(alllen * (9 - ep) * 0.1) + 1:int(alllen * (10 - ep) * 0.1)])

    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=False)
    val_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    tflog = SummaryWriter('./anmylog/' + str(ep))
    # CrossEntropyLoss用于不平衡的训练集.熵最小化,一致性正则化
    criterion = nn.CrossEntropyLoss().to(device)
    # criterion = nn.MultiLabelSoftMarginLoss().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    sche = lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.1, patience=10)
    train_end = trainend(patience=20, verbose=True)
    train_len = len(train_loader.dataset)
    val_len = len(val_loader.dataset)

    for epoch in range(EPOCHS):
        train_loss = 0.00
        val_loss = 0.00
        train_accuracy = 0.0
        val_accuracy = 0.0
        crr = 0
        val_crr = 0
        print(f'Epoch {epoch + 1}')

        # Training loop
        for idx, (inputs, labels) in enumerate(Bar(train_loader)):
            model.train()
            # if hasattr(torch.cuda, 'empty_cache'):
            #     torch.cuda.empty_cache()
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            prediction = torch.argmax(outputs, 1)
            # criten_label = torch.nn.functional.one_hot(labels, num_classes=n_classes).float()
            # print(outputs,labels)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
            # print(outputs,prediction, labels)
            crr += torch.eq(prediction, labels).sum().float().item()
            # print("prediction", prediction)
            # print("labels", labels)
            # print(crr, train_len)
            # exit(0)
        train_loss /= train_len
        sche.step(train_loss)
        train_accuracy = crr / train_len
        print(f"Train Accuracy: {train_accuracy}")
        train_loss_formated = "{:.4f}".format(train_loss)
        tflog.add_scalar("train_loss", train_loss, epoch)
        tflog.add_scalar("Train Accuracy", train_accuracy, epoch)

        # Validation loop
        test_acc = torchmetrics.Accuracy(task='multiclass', num_classes=n_classes).to(device)
        test_recall = torchmetrics.Recall(task='multiclass', average='none', num_classes=n_classes).to(device)
        test_precision = torchmetrics.Precision(task='multiclass', average='none', num_classes=n_classes).to(device)
        test_f1 = torchmetrics.F1Score(task='multiclass', average="none", num_classes=n_classes).to(device)
        with torch.no_grad():
            for inputs, labels in val_loader:
                model.eval()
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                # criten_label = torch.nn.functional.one_hot(labels, num_classes=n_classes).float()
                loss = criterion(outputs, labels)
                val_loss += loss.item()
                predicted = torch.argmax(outputs, 1)
                val_crr += torch.eq(predicted, labels).sum().float().item()
                # print("val_crr", val_crr)
                # recall = recall_score(labels.to('cpu'), predicted.to('cpu'))
                # precision = precision_score(labels.to('cpu'), predicted.to('cpu'))
                # F1 = f1_score(labels.to('cpu'), predicted.to('cpu'))
                test_acc(predicted, labels)
                test_recall(predicted, labels)
                test_precision(predicted, labels)
                test_f1(predicted, labels)

            val_accuracy = val_crr / val_len
            total_acc = test_acc.compute()
            total_recall = test_recall.compute()
            total_precision = test_precision.compute()
            total_f1 = test_f1.compute()

            val_loss /= val_len
            val_loss_formated = "{:.4f}".format(val_loss)

            print('total_acc{} ,Test Acc {}, recal {}, precision {}, F1-score {}'.format(total_acc, val_accuracy,
                                                                                         total_recall, total_precision,
                                                                                         total_f1))
            tflog.add_scalar("test_accuracy", val_accuracy, epoch)
            tflog.add_scalars("recall", {'0': total_recall[0],
                                         '1': total_recall[1],
                                         '2': total_recall[2],
                                         '3': total_recall[3],
                                         }, epoch)
            tflog.add_scalars("precision", {'0': total_precision[0],
                                            '1': total_precision[1],
                                            '2': total_precision[2],
                                            '3': total_precision[3],
                                            }, epoch)
            tflog.add_scalars("F1-score", {'0': total_f1[0],
                                           '1': total_f1[1],
                                           '2': total_f1[2],
                                           '3': total_f1[3],
                                           }, epoch)

    train_end(val_accuracy, model)
    if train_end.traend:
        break

    tflog.close()



