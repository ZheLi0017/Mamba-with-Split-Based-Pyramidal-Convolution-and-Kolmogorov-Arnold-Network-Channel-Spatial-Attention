import torch
import torch.nn as nn
from mambapy.vim import MambaConfig, ResidualBlock,RMSNorm
from mambapy.pscan import pscan
import torchsummary


class VMamba(nn.Module):
    def __init__(self, config: MambaConfig):
        super().__init__()

        self.config = config
        self.layers = nn.ModuleList([ResidualBlock(config) for _ in range(config.n_layers)])

        # for i, layer in enumerate(self.layers):
        #     layer: ResidualBlock

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

    def step(self, x, caches):
        for i, layer in enumerate(self.layers):
            x, caches[i] = layer.step(x, caches[i])
        return x, caches


class MambaModel(nn.Module):
    def __init__(self,in_ch,n_cla,d_model):
        super().__init__()

        self.in_proj = nn.Conv1d(in_ch, d_model, kernel_size=3, padding=1)

        config = MambaConfig(
        d_model=256,
        n_layers = 3,
        dt_rank = 'auto',
        d_state = 16,
        expand_factor = 2,
        d_conv = 4,
        dt_min = 0.001,
        dt_max = 0.1,
        dt_init = "random",
        dt_scale = 1.0,
        )
        self.mamba = VMamba(config)

        self.predictor = nn.Linear(d_model, n_cla)

    def forward(self, x):
        x = self.in_proj(x)
        x = x.permute(0, 2, 1)
        x = self.mamba(x)
        # print(x.shape)
        x = x.mean(dim=1)
        # print(x.shape)
        return self.predictor(x)


# inputs = torch.randn([1,3,100])
m = MambaModel(3,10,256).to('cuda')
print(torchsummary.summary(m,(3,100),4,device='cuda'))
# out = m(inputs)
# print(out.shape)


