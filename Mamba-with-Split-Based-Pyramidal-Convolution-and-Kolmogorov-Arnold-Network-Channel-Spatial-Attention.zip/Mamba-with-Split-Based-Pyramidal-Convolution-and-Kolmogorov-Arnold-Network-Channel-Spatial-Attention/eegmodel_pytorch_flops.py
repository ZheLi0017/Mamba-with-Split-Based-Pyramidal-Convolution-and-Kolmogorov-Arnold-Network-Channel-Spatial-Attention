import torch
import torch.nn as nn
import torch.nn.functional as F
from dpeeg.models import ShallowConvNet,EEGNet
from mambapy.mamba import MambaConfig, ResidualBlock

class EEGNet_fusion_V2(nn.Module):
    def __init__(self, nb_classes, Chans=64, Samples=128, dropoutRate=0.5, norm_rate=0.25, cpu=False):
        super(EEGNet_fusion_V2, self).__init__()

        self.cpu = cpu
        self.dropoutRate = dropoutRate
        self.norm_rate = norm_rate

        self.input_shape = (1, Chans, Samples)

        # Branch 1
        self.branch1 = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=(1, 64), padding='same', bias=False),
            nn.BatchNorm2d(8),
            nn.Conv2d(8, 16, kernel_size=(Chans, 1), groups=8, bias=False),
            nn.BatchNorm2d(16),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(16, 16, kernel_size=(1, 8), padding='same',groups=16,bias=False),
            nn.BatchNorm2d(16),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Branch 2
        self.branch2 = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=(1, 80), padding='same', bias=False),
            nn.BatchNorm2d(16),
            nn.Conv2d(16, 32, kernel_size=(Chans, 1), groups=16, bias=False),
            nn.BatchNorm2d(32),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(32, 32, kernel_size=(1, 16), padding='same',groups=32, bias=False),
            nn.BatchNorm2d(32),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Branch 3
        self.branch3 = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=(1, 96), padding='same', bias=False),
            nn.BatchNorm2d(32),
            nn.Conv2d(32, 64, kernel_size=(Chans, 1), groups=32, bias=False),
            nn.BatchNorm2d(64),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(64, 64, kernel_size=(1, 32), padding='same', bias=False),
            nn.BatchNorm2d(64),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Branch 4
        self.branch4 = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=(1, 112), padding='same', bias=False),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 128, kernel_size=(Chans, 1), groups=64, bias=False),
            nn.BatchNorm2d(128),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(128, 128, kernel_size=(1, 64), padding='same', bias=False),
            nn.BatchNorm2d(128),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Branch 5
        self.branch5 = nn.Sequential(
            nn.Conv2d(1, 128, kernel_size=(1, 128), padding='same', bias=False),
            nn.BatchNorm2d(128),
            nn.Conv2d(128, 256, kernel_size=(Chans, 1), groups=128, bias=False),
            nn.BatchNorm2d(256),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(256, 256, kernel_size=(1, 128), padding='same', bias=False),
            nn.BatchNorm2d(256),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Classifier
        self.classifier = nn.Sequential(
            nn.Linear(int(Samples/2) + Samples + Samples * 2 + Samples * 4 + Samples * 8, nb_classes),
            nn.Softmax(dim=1)
        )

    def forward(self, x1, x2, x3, x4, x5):
        # print(x1.shape)
        x1 = self.branch1(x1)
        # print(x1.shape)
        x2 = self.branch2(x2)
        # print(x2.shape)
        x3 = self.branch3(x3)
        # print(x3.shape)
        x4 = self.branch4(x4)
        # print(x4.shape)
        x5 = self.branch5(x5)
        # print(x5.shape)

        x = torch.cat((x1, x2, x3, x4, x5), dim=1)
        x = self.classifier(x)
        return x

class DeepConvNet(nn.Module):
    def __init__(self, nb_classes, Chans=64, Samples=256, dropoutRate=0.5, cpu=False):
        super(DeepConvNet, self).__init__()
        self.cpu = cpu
        self.dropoutRate = dropoutRate

        self.input_shape = (1, Chans, Samples)

        # Block 1
        self.block1 = nn.Sequential(
            nn.Conv2d(1, 25, kernel_size=(1, 2), padding=(0,1) ,bias=False),
            nn.Conv2d(25, 25, kernel_size=(Chans, 1), bias=False),
            nn.BatchNorm2d(25),
            nn.ELU(),
            nn.MaxPool2d((1, 2), stride=(1, 2)),
            nn.Dropout(dropoutRate)
        )

        # Block 2
        self.block2 = nn.Sequential(
            nn.Conv2d(25, 50, kernel_size=(1, 2),padding=(0,1), bias=False),
            nn.BatchNorm2d(50),
            nn.ELU(),
            nn.MaxPool2d((1, 2), stride=(1, 2)),
            nn.Dropout(dropoutRate)
        )

        # Block 3
        self.block3 = nn.Sequential(
            nn.Conv2d(50, 100, kernel_size=(1, 2),padding=(0,1), bias=False),
            nn.BatchNorm2d(100),
            nn.ELU(),
            nn.MaxPool2d((1, 2), stride=(1, 2)),
            nn.Dropout(dropoutRate)
        )

        # Block 4
        self.block4 = nn.Sequential(
            nn.Conv2d(100, 200, kernel_size=(1, 2),padding=(0,1), bias=False),
            nn.BatchNorm2d(200),
            nn.ELU(),
            nn.MaxPool2d((1, 2), stride=(1, 2)),
            nn.Dropout(dropoutRate)
        )

        # Classifier
        self.flatten = nn.Flatten()
        self.classifier = nn.Sequential(
            nn.Linear(200 * (Samples // 16), nb_classes),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        x = self.block1(x)
        # print(x.shape)
        x = self.block2(x)
        # print(x.shape)
        x = self.block3(x)
        # print(x.shape)
        x = self.block4(x)
        # print(x.shape)
        x = self.flatten(x)
        # print(x.shape)
        x = self.classifier(x)
        return x

class EEGNet_fusion(nn.Module):
    def __init__(self, nb_classes, Chans=64, Samples=128, dropoutRate=0.5, norm_rate=0.25, cpu=False):
        super(EEGNet_fusion, self).__init__()
        self.cpu = cpu
        self.dropoutRate = dropoutRate
        self.norm_rate = norm_rate
        self.input_shape = (1, Samples, Chans)

        # Branch 1
        self.branch1 = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=(1, 64), padding='same', bias=False),
            nn.BatchNorm2d(8),
            nn.Conv2d(8, 16, kernel_size=(Chans,1), groups=8, bias=False),
            nn.BatchNorm2d(16),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(16, 16, kernel_size=(1, 8), padding='same',groups=16, bias=False),
            nn.BatchNorm2d(16),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Branch 2
        self.branch2 = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=(1, 96), padding='same', bias=False),
            nn.BatchNorm2d(16),
            nn.Conv2d(16, 32, kernel_size=(Chans, 1), groups=16, bias=False),
            nn.BatchNorm2d(32),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(32, 32, kernel_size=(1, 16), padding='same',groups=32, bias=False),
            nn.BatchNorm2d(32),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Branch 3
        self.branch3 = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=(1, 128), padding='same', bias=False),
            nn.BatchNorm2d(32),
            nn.Conv2d(32, 64, kernel_size=(Chans, 1), groups=32, bias=False),
            nn.BatchNorm2d(64),
            nn.ELU(),
            nn.AvgPool2d((1, 4)),
            nn.Dropout(dropoutRate),
            nn.Conv2d(64, 64, kernel_size=(1, 32), padding='same',groups=64, bias=False),
            nn.BatchNorm2d(64),
            nn.ELU(),
            nn.AvgPool2d((1, 8)),
            nn.Dropout(dropoutRate),
            nn.Flatten()
        )

        # Classifier
        self.classifier = nn.Sequential(
            nn.Linear(int(Samples/2) + Samples + Samples * 2, nb_classes),
            nn.Softmax(dim=1)
        )

    def forward(self, x1, x2, x3):
        # print(x1.shape)
        x1 = self.branch1(x1)
        # print(x1.shape)
        x2 = self.branch2(x2)
        # print(x2.shape)
        x3 = self.branch3(x3)
        # print(x3.shape)

        # Concatenate features from different branches
        x = torch.cat((x1, x2, x3), dim=1)
        # print(x.shape)
        x = self.classifier(x)
        return x

batch_size = 24
Chans = 64
Samples = 160
n_cls = 2

model = ShallowConvNet(nCh=Chans,nTime=Samples,nCls=n_cls)
from thop import profile, clever_format
input = torch.randn(batch_size,1,Chans,Samples)
macs, params = profile(model, inputs=(input, ))
macs, params = clever_format([macs, params], "%.3f")
print("The model ShallowConvNet info: ", macs, params)

model = EEGNet(nCh=Chans,nTime=Samples,nCls=n_cls)
from thop import profile, clever_format
input = torch.randn(batch_size,1,Chans,Samples)
macs, params = profile(model, inputs=(input, ))
macs, params = clever_format([macs, params], "%.3f")
print("The model EEGNet info: ", macs, params)

model = DeepConvNet(nb_classes=n_cls, Chans=Chans, Samples=Samples, dropoutRate=0.5, cpu=False)
from thop import profile, clever_format
input = torch.randn(batch_size,1,Chans,Samples)
macs, params = profile(model, inputs=(input, ))
macs, params = clever_format([macs, params], "%.3f")
print("The model DeepConvNet info: ", macs, params)


model = EEGNet_fusion(nb_classes=n_cls, Chans=Chans, Samples=Samples, cpu=True)
from thop import profile, clever_format
input = torch.randn(batch_size,1,Chans,Samples)
macs, params = profile(model, inputs=(input,input,input,))
macs, params = clever_format([macs, params], "%.3f")
print("The model EEGNet_fusion info: ", macs, params)

model = EEGNet_fusion_V2(nb_classes=n_cls, Chans=Chans, Samples=Samples, cpu=True)
from thop import profile, clever_format
input = torch.randn(batch_size,1,Chans,Samples)
macs, params = profile(model, inputs=(input,input,input,input,input,))
macs, params = clever_format([macs, params], "%.3f")
print("The model EEGNet_fusion_V2 info: ", macs, params)
